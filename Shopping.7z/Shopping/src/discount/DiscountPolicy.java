package discount;

public interface DiscountPolicy {
	double applyDiscount(double totalAmount);

}
