package basic;

public enum ItemType {
	GROCERY,
	OTHER,

}
