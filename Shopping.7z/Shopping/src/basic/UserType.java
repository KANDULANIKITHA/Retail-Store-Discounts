package basic;

public enum UserType {
	EMPLOYEE,
	AFFILIATE,
	CUSTOMER
}
