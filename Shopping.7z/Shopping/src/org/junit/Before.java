package org.junit;

public class Before {

}
